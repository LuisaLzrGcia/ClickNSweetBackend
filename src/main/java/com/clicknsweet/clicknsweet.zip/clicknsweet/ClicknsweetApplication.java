package com.clicknsweet.clicknsweet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClicknsweetApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClicknsweetApplication.class, args);
	}

}
